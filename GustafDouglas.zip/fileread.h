#ifndef FILEREAD_H
#define FILEREAD_H

int fileread(const char* filename, char** out);

#endif // FILEREAD_H
