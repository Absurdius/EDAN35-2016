#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "fileread.h"

// Remove C4244 warnings for this file only
#pragma warning(push)
#pragma warning(disable: 4244)
#include "linmath.h"
#pragma warning(pop)


/*

Link with
*glfw3: http://www.glfw.org/download.html



*/
struct curve_array {
	GLfloat curve[128];
};

static GLuint createShader(GLenum shaderType, char* filename);
static void bindUniforms(int flame_num);
curve_array makeArray(float lean, float anchor, float amplitude, float wavelength, float speed, float time);

static void error_callback(int error, const char* description) {
	fprintf(stderr, "Error: %s\n", description);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);
}

GLuint program;

int main(void) {
	GLFWwindow* window;
	GLuint vertex_shader, fragment_shader;
	glfwSetErrorCallback(error_callback);
	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	window = glfwCreateWindow(640, 480, "ATTENTION USER, YOUR COMPUTER IS NOT ON FIRE!", NULL, NULL);
	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwSetKeyCallback(window, key_callback);
	glfwMakeContextCurrent(window);
	gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
	glfwSwapInterval(1);
	vertex_shader = createShader(GL_VERTEX_SHADER, "shader.vert");
	fragment_shader = createShader(GL_FRAGMENT_SHADER, "shader.frag");
	program = glCreateProgram();
	glAttachShader(program, vertex_shader);
	glAttachShader(program, fragment_shader);
	glLinkProgram(program);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	while (!glfwWindowShouldClose(window)) {
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);
		glUseProgram(program);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		for (int i = 0; i < 3; i++) {
			bindUniforms(i);
			glDrawArrays(GL_TRIANGLES, 0, 3);
		}
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	glfwDestroyWindow(window);
	glfwTerminate();
	exit(EXIT_SUCCESS);
}

static void bindUniforms(int flame_num) {
	float time = (float)glfwGetTime();
	curve_array left, right;

	// lean anchor amplitude wavelength speed time // take these with a pinch of salt. 
	switch (flame_num) {
		case 0:
			//                                                  lean,                       anchor, amplitude, wavelength, speed, time) {
			left  = makeArray( 2.7f + 0.3f * (float)sin(1.0f * time), -2.2f                       ,     0.25f,      0.08f, 20.0f, time);
			right = makeArray(-2.7f + 0.5f * (float)sin(2.0f * time),  2.2f                       ,     0.17f,      0.15f, 25.0f, time);
			break;
		case 1:
			left  = makeArray( 0.9f + 0.2f * (float)sin(3.0f * time), -2.2f                       ,     0.11f,      0.19f, 30.0f, time);
			right = makeArray(-2.3f + 0.2f * (float)sin(5.0f * time), 0.09f                       ,     0.13f,      0.25f, 25.0f, time);
			break;
		case 2:
			left  = makeArray( 2.4f + 0.4f * (float)sin(5.0f * time), 0.3f                        ,     0.09f,      0.28f, 30.0f, time);
			right = makeArray(-0.6f + 0.3f * (float)sin(3.0f * time), 2.2f + 0.1f*(float)sin(time),     0.12f,      0.19f, 27.0f, time);
			break;
	}

	glUniform1fv(glGetUniformLocation(program, "curve_left"), 128, left.curve);
	glUniform1fv(glGetUniformLocation(program, "curve_right"), 128, right.curve);
}

curve_array makeArray(float lean, float anchor, float amplitude, float wavelength, float speed, float time) {
	curve_array c;
	for (int i = 0; i < 128; i++) {
		c.curve[i] = (float)i / 128 * lean + anchor // linear part
			+ amplitude * (float)sin((float)i*wavelength - (speed * time)); // sine part
	}
	return c;
}

static GLuint createShader(GLenum shaderType, char* filename) {
	GLchar *text;
	int ret = fileread(filename, &text);
	if (ret == 0) {
		printf("Problem reading shader file");
		return 0;
	}
	GLuint shader = glCreateShader(shaderType);
	if (shader == 0) {
		printf("Couldn't create shader");
		return 0;
	}
	glShaderSource(shader, 1, &text, NULL);
	glCompileShader(shader);
	GLint status;
	glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
	//if (status == GL_FALSE) {
		GLint logLength;
		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLength);
		GLchar* log = new GLchar[logLength];
		glGetShaderInfoLog(shader, logLength, NULL, log);
		printf(log);
		delete[] log;
	//}
	return shader;
}
 