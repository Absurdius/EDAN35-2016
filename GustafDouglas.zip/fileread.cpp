#include <stdio.h>
#include <stdlib.h>

#include "fileread.h"

int fileread(const char* filename, char** out) {
	FILE *fp;
	long sz;
	char *buf;
	int err;

	err = fopen_s(&fp, filename, "rb");
	if (err != 0) return 0;

	// Get file size
	fseek(fp, 0, SEEK_END);
	sz = ftell(fp);
	rewind(fp);

	buf = (char*)malloc(sz+1);
	int read = fread(buf, 1, sz, fp);
	if (!buf || read != sz) {
		fclose(fp);
		return 0;
	}
	buf[sz] = 0;

	fclose(fp);
	*out = buf;
	return 1;
}
